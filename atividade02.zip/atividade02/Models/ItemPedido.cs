namespace atividade02
{
    public class ItemPedido
    {
        public string Item {get; set;}
        public int Quantidade {get; set;}
        public double Valor_Unitario {get; set;}
    }
} 