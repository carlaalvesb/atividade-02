using System.Collections.Generic;

namespace atividade02
 {
    public class Pedido
    {
        private static List<ItemPedido> Lista = new List<ItemPedido>();

        public static void Incluir(ItemPedido ItemPedido)
        {
            Lista.Add(ItemPedido);
        }

        public static double Total()
        {
            double total = 0;
            for (int i = 0; i < Lista.Count; i++)
            {
            total = Lista[i].Valor_Unitario * Lista[i].Quantidade + total;;
            }

            return total;
        }

        public static List<ItemPedido> Listar()
        {
            return Lista;
        }
    }
}
